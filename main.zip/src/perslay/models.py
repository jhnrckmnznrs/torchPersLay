import torch
import torch.nn as nn

from .layers import (
    ConstantPerslayWeight,
    GaussianPerslayPhi,
    LearnablePowerPerslayWeight,
    MLPPerslayWeight,
    NormalizedLearnablePowerPerslayWeight,
    Perslay,
)


class FlattenRho(nn.Module):
    def forward(self, x):
        return x.reshape(x.shape[0], -1)


class PerslayRegressor(nn.Module):
    def __init__(
        self,
        image_size,
        image_bnds,
        sigma_x,
        sigma_y,
        hidden_dim=64,
        weight_type="learnable_power",
        weight_hidden_dim=16,
    ):
        super().__init__()

        if weight_type == "constant":
            weight = ConstantPerslayWeight()

        elif weight_type == "learnable_power":
            weight = LearnablePowerPerslayWeight(
                init_scale=1.0,
                init_power=1.0,
            )

        elif weight_type == "mlp":
            weight = MLPPerslayWeight(
                image_bnds=image_bnds,
                hidden_dim=weight_hidden_dim,
            )

        elif weight_type == "normalized_learnable_power":
            weight = NormalizedLearnablePowerPerslayWeight(
                image_bnds=image_bnds,
                init_scale=1.0,
                init_power=1.0,
            )

        else:
            raise ValueError(f"Unknown weight_type: {weight_type}")

        phi = GaussianPerslayPhi(
            image_size=image_size,
            image_bnds=image_bnds,
            sigma_x=sigma_x,
            sigma_y=sigma_y,
            normalize=False,
        )

        rho = FlattenRho()

        self.perslay = Perslay(
            weight=weight,
            phi=phi,
            perm_op=torch.sum,
            rho=rho,
        )

        feature_dim = image_size[0] * image_size[1]

        self.regressor = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, diagrams, mask=None):
        x = self.perslay(diagrams, mask=mask)
        y = self.regressor(x).squeeze(-1)
        return y


class MultiPerslayRegressor(nn.Module):
    """
    Multi-branch PersLay regressor.

    Example input:
        diagrams = {
            "h0": Tensor[B, N0, 2],
            "h2": Tensor[B, N2, 2],
        }

        mask = {
            "h0": Tensor[B, N0],
            "h2": Tensor[B, N2],
        }
    """

    def __init__(
        self,
        branch_configs,
        hidden_dim=64,
        weight_type="learnable_power",
        weight_hidden_dim=16,
        dropout=0.0,
    ):
        super().__init__()

        self.branch_names = list(branch_configs.keys())
        self.branches = nn.ModuleDict()

        total_feature_dim = 0

        for name, cfg in branch_configs.items():
            branch = PerslayRegressor(
                image_size=cfg["image_size"],
                image_bnds=cfg["image_bnds"],
                sigma_x=cfg["sigma_x"],
                sigma_y=cfg["sigma_y"],
                hidden_dim=hidden_dim,
                weight_type=weight_type,
                weight_hidden_dim=weight_hidden_dim,
            )

            # Use only the PersLay feature extractor from the branch.
            self.branches[name] = branch.perslay

            total_feature_dim += cfg["image_size"][0] * cfg["image_size"][1]

        self.regressor = nn.Sequential(
            nn.Linear(total_feature_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, diagrams, mask=None):
        features = []

        for name in self.branch_names:
            branch_mask = None
            if mask is not None:
                branch_mask = mask[name]

            x = self.branches[name](
                diagrams[name],
                mask=branch_mask,
            )

            features.append(x)

        x = torch.cat(features, dim=-1)
        y = self.regressor(x).squeeze(-1)

        return y


class DiagramDeepSetRegressor(nn.Module):
    """
    DeepSets regressor for persistence diagrams.

    Input diagrams are expected as birth-death pairs with shape [B, N, 2].
    Internally, points are converted to birth-persistence coordinates:

        (birth, death) -> (birth, death - birth)

    The model applies a shared pointwise MLP to every persistence point, pools
    over points using a permutation-invariant operation, and predicts one scalar.
    """

    def __init__(
        self,
        image_bnds,
        point_hidden_dim=64,
        set_hidden_dim=64,
        pooling="sum_mean",
        dropout=0.0,
        eps=1e-8,
    ):
        super().__init__()

        self.pooling = pooling
        self.eps = eps

        # Use the same automatically computed bounds as the PersLay model,
        # but only for coordinate normalization.
        mins = torch.tensor(
            [image_bnds[0][0], image_bnds[1][0]],
            dtype=torch.float32,
        )
        maxs = torch.tensor(
            [image_bnds[0][1], image_bnds[1][1]],
            dtype=torch.float32,
        )

        self.register_buffer("mins", mins)
        self.register_buffer("ranges", (maxs - mins).clamp_min(eps))

        self.point_mlp = nn.Sequential(
            nn.Linear(2, point_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(point_hidden_dim, point_hidden_dim),
            nn.ReLU(),
        )

        if pooling == "sum_mean":
            pooled_dim = 2 * point_hidden_dim
        elif pooling in {"sum", "mean", "max"}:
            pooled_dim = point_hidden_dim
        else:
            raise ValueError(f"Unknown pooling method: {pooling}")

        self.regressor = nn.Sequential(
            nn.Linear(pooled_dim, set_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(set_hidden_dim, 1),
        )

    def forward(self, diagrams, mask=None):
        """
        Args:
            diagrams: [B, N, 2] tensor of birth-death pairs
            mask: optional [B, N] boolean tensor.
                  True means real point; False means padding.

        Returns:
            predictions: [B]
        """

        birth = diagrams[..., 0:1]
        death = diagrams[..., 1:2]
        persistence = death - birth

        x = torch.cat([birth, persistence], dim=-1)  # [B, N, 2]

        # Normalize birth and persistence coordinates.
        x = (x - self.mins) / self.ranges

        h = self.point_mlp(x)  # [B, N, H]

        if mask is not None:
            mask_float = mask.unsqueeze(-1).to(h.dtype)
            h = h * mask_float
            counts = mask_float.sum(dim=1).clamp_min(1.0)
        else:
            counts = torch.tensor(
                h.shape[1],
                dtype=h.dtype,
                device=h.device,
            )

        if self.pooling == "sum":
            pooled = h.sum(dim=1)

        elif self.pooling == "mean":
            pooled = h.sum(dim=1) / counts

        elif self.pooling == "sum_mean":
            pooled_sum = h.sum(dim=1)
            pooled_mean = pooled_sum / counts
            pooled = torch.cat([pooled_sum, pooled_mean], dim=-1)

        elif self.pooling == "max":
            if mask is not None:
                h_masked = h.masked_fill(~mask.unsqueeze(-1), float("-inf"))
                pooled = h_masked.max(dim=1).values
                pooled = torch.where(
                    torch.isfinite(pooled),
                    pooled,
                    torch.zeros_like(pooled),
                )
            else:
                pooled = h.max(dim=1).values

        else:
            raise ValueError(f"Unknown pooling method: {self.pooling}")

        return self.regressor(pooled).squeeze(-1)
